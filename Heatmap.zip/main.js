window.onload = init;

function init(){
  // Controls
  const fullScreenControl = new ol.control.FullScreen();
  const mousePositionControl = new ol.control.MousePosition();

  const overViewMapControl = new ol.control.OverviewMap({
    tipLabel: 'Custom Overview Map',
    collapsed: true,
    layers: [
      new ol.layer.Tile({
        source: new ol.source.OSM({
          url: 'https://{a-c}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png'
        }),
      })
    ]
  });
  const scaleLineControl = new ol.control.ScaleLine({

    units: 'metric',
    minWidth: 200,
    bar: true,
    steps: 4,
    text: true

  } );
  const zoomSliderControl = new ol.control.ZoomSlider();
  const zoomToExtentControl = new ol.control.ZoomToExtent();

  const map = new ol.Map({
    view: new ol.View({
      center: [11946323.686849108,2419495.5059337737],
      zoom: 10,
      maxZoom: 14,
      minZoom: 8,
      rotation: 0
    }),

    layers: [
      new ol.layer.Tile({
        source: new ol.source.OSM({
          url: 'https://{a-c}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png'
        }),
        visible: true,
        title: 'StamenTerrain'

      })
    ],
    target: 'js-map',
    keyboardEventTarget: document,
    controls: ol.control.defaults().extend([
      fullScreenControl,
      mousePositionControl,
      overViewMapControl,
      scaleLineControl,
      zoomSliderControl,
      zoomToExtentControl

    ])
  })


  // Vector Layers
  // Central EU Countries GeoJSON VectorImage Layer
   // Styling of vector features
  // Style for polygons


    // Style for lines


  const strokeStyle = new ol.style.Stroke({
    color: [30, 30, 31, 1],
    width: 1.4,
    lineCap: 'square',
    lineJoin: 'bevel',
    lineDash: [1, 1]
  })

  // Icon Marker Style

  const QuangNinh = new ol.layer.VectorImage({
    source: new ol.source.Vector({
      url: './GISdata/Quang Ninh map.geojson',
      format: new ol.format.GeoJSON()
    }),
    visible: true,
    title: 'QuangNinh',
    style: new ol.style.Style({

      stroke: strokeStyle,

    })
  })


  // Icon Marker Style

  const mangroves2018 = new ol.layer.Heatmap({
    source: new ol.source.Vector({
      url: './GISdata/Hotspots.geojson',
      format: new ol.format.GeoJSON()
    }),

    radius: 5,
    blur: 8,

    title: 'Mangrove Hotspot',

    gradient: ['#1a9641', '#a6d96a', '#ffffc0', '#ebf703', '#e62f21','#bd0026'],


  })
  // Icon Marker Style


  // Layer Group
  const layerGroup = new ol.layer.Group({
    layers:[
      QuangNinh,  mangroves2018

    ]
  })
  map.addLayer(layerGroup);


  // Layer Switcher Logic for Raster Tile Layers
  const tileRasterLayerElements = document.querySelectorAll('.sidebar > input[type=checkbox]');
  for(let tileRasterLayerElement of tileRasterLayerElements){
    tileRasterLayerElement.addEventListener('change', function(){
      let tileRasterLayerElementValue = this.value;
      let tileRasterLayer;

      layerGroup.getLayers().forEach(function(element, index, array){
        if(tileRasterLayerElementValue === element.get('title')){
          tileRasterLayer = element;
        }
      })
      this.checked ? tileRasterLayer.setVisible(true) : tileRasterLayer.setVisible(false)
    })
  }








}
